#[derive(Debug, thiserror::Error)]
#[error("Invalid ID")]
pub struct InvalidId;
