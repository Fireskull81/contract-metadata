fn main() {
    startos::bins::startbox()
}
