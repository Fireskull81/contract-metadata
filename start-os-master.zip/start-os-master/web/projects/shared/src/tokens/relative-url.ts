import { InjectionToken } from '@angular/core'

export const RELATIVE_URL = new InjectionToken<string>(
  'Relative URL for requests',
)
